package com.sonarsecurity.radar;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(6, 17, 23);
    private static final int CARD = Color.rgb(15, 37, 43);
    private static final int GREEN = Color.rgb(68, 237, 155);
    private static final int MUTED = Color.rgb(147, 180, 176);
    private static final int WHITE = Color.rgb(229, 247, 242);
    private static final int RED = Color.rgb(255, 111, 99);
    private static final String ACTION_USB_PERMISSION = "com.sonarsecurity.radar.USB_PERMISSION";
    private static final Pattern DATA_PATTERN = Pattern.compile("Angle:\\s*(\\d+)\\s*\\|\\s*Distance:\\s*(-?\\d+(?:\\.\\d+)?)");

    private final Handler handler = new Handler(Looper.getMainLooper());
    private UsbManager usbManager;
    private UsbSerialPort serialPort;
    private UsbSerialDriver pendingDriver;
    private UsbDevice currentDevice;
    private volatile boolean reading = false;
    private long sessionId = 0;
    private boolean demoRunning = false;
    private int demoAngle = 35;
    private int demoStep = 5;

    private RadarView radar;
    private TextView statusText;
    private TextView angleText;
    private TextView distanceText;
    private TextView detectionText;
    private TextView sampleText;
    private Button connectButton;
    private Button demoButton;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_USB_PERMISSION.equals(intent.getAction())) {
                boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                if (granted && pendingDriver != null) {
                    UsbSerialDriver driver = pendingDriver;
                    pendingDriver = null;
                    openSerial(driver);
                } else {
                    pendingDriver = null;
                    setStatus("Доступ к USB не разрешён", RED);
                }
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(intent.getAction())) {
                UsbDevice detached = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (currentDevice != null && currentDevice.equals(detached)) {
                    disconnect("Arduino отключена");
                }
            }
        }
    };

    private final Runnable demoTicker = new Runnable() {
        @Override
        public void run() {
            if (!demoRunning) return;
            double a = Math.toRadians(demoAngle);
            double noise = Math.sin(demoAngle * 0.31) * 2.8;
            float distance = (float)(230 + 35 * Math.sin(a * 4) + noise);
            if (demoAngle >= 48 && demoAngle <= 64) distance = (float)(20 + Math.sin(a * 2) * 1.5);
            else if (demoAngle >= 110 && demoAngle <= 122) distance = 88f;
            acceptMeasurement(demoAngle, distance, true);
            demoAngle += demoStep;
            if (demoAngle >= 145) { demoAngle = 145; demoStep = -5; }
            if (demoAngle <= 35) { demoAngle = 35; demoStep = 5; }
            handler.postDelayed(this, 125);
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        getWindow().getDecorView().setSystemUiVisibility(0);
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(usbReceiver, filter);
        }
        buildInterface();
        setStatus("Ожидание подключения Arduino", MUTED);
    }

    private int dp(float dp) {
        return (int)(dp * getResources().getDisplayMetrics().density + .5f);
    }

    private GradientDrawable bg(int color, float radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private GradientDrawable outlinedBg(int color, int stroke, float radiusDp) {
        GradientDrawable drawable = bg(color, radiusDp);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private TextView label(String text, int sizeSp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(20), dp(16), dp(26));
        scroll.addView(content);
        setContentView(scroll);

        TextView title = label("SONAR SECURITY", 23, GREEN, true);
        content.addView(title);
        TextView subtitle = label("USB RADAR  ·  ARDUINO UNO R3", 11, MUTED, true);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(4);
        content.addView(subtitle, subLp);

        statusText = label("", 12, MUTED, false);
        statusText.setPadding(dp(12), dp(9), dp(12), dp(9));
        statusText.setBackground(outlinedBg(CARD, Color.rgb(31, 69, 62), 10));
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(15);
        content.addView(statusText, statusLp);

        radar = new RadarView(this);
        radar.setBackground(bg(CARD, 14));
        LinearLayout.LayoutParams radarLp = new LinearLayout.LayoutParams(-1, dp(325));
        radarLp.topMargin = dp(12);
        content.addView(radar, radarLp);

        LinearLayout metricRow = new LinearLayout(this);
        metricRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams metricsLp = new LinearLayout.LayoutParams(-1, dp(85));
        metricsLp.topMargin = dp(12);
        content.addView(metricRow, metricsLp);
        angleText = addMetric(metricRow, "УГОЛ", "—", GREEN);
        distanceText = addMetric(metricRow, "РАССТОЯНИЕ", "—", GREEN);
        detectionText = addMetric(metricRow, "СТАТУС", "ОЖИДАНИЕ", MUTED);

        LinearLayout buttonRow = new LinearLayout(this);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams buttonsLp = new LinearLayout.LayoutParams(-1, dp(51));
        buttonsLp.topMargin = dp(16);
        content.addView(buttonRow, buttonsLp);
        connectButton = addButton(buttonRow, "Подключить USB", Color.rgb(25, 129, 88), WHITE);
        demoButton = addButton(buttonRow, "Демо", CARD, GREEN);

        Button clearButton = new Button(this);
        clearButton.setAllCaps(false);
        clearButton.setText("Очистить точки");
        clearButton.setTextSize(13);
        clearButton.setTextColor(WHITE);
        clearButton.setBackground(outlinedBg(CARD, Color.rgb(35, 89, 77), 10));
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(-1, dp(46));
        clearLp.topMargin = dp(9);
        content.addView(clearButton, clearLp);

        sampleText = label("Ожидаю данные: Angle: 45 | Distance: 20.5", 12, MUTED, false);
        sampleText.setPadding(dp(4), dp(14), 0, 0);
        content.addView(sampleText);

        TextView help = label("Кабель USB-OTG · 9600 бод · открывай только одно USB-приложение за раз. Красная точка означает расстояние до 25 см. При -1 отражённый сигнал не получен.", 12, MUTED, false);
        help.setPadding(dp(4), dp(10), dp(4), 0);
        content.addView(help);

        connectButton.setOnClickListener(v -> {
            if (serialPort != null) disconnect("USB отключено");
            else connectUsb();
        });
        demoButton.setOnClickListener(v -> {
            if (demoRunning) stopDemo();
            else startDemo();
        });
        clearButton.setOnClickListener(v -> radar.clearTargets());
    }

    private TextView addMetric(LinearLayout row, String label, String value, int valueColor) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(9), dp(12), dp(4), dp(6));
        box.setBackground(bg(CARD, 10));
        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(0, -1, 1);
        boxLp.setMargins(dp(3), 0, dp(3), 0);
        row.addView(box, boxLp);
        TextView name = label(label, 10, MUTED, true);
        box.addView(name);
        TextView amount = label(value, 19, valueColor, true);
        amount.setSingleLine(true);
        amount.setTextScaleX(0.85f);
        LinearLayout.LayoutParams amountLp = new LinearLayout.LayoutParams(-1, -2);
        amountLp.topMargin = dp(6);
        box.addView(amount, amountLp);
        return amount;
    }

    private Button addButton(LinearLayout row, String label, int background, int color) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setTextColor(color);
        button.setBackground(bg(background, 10));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -1, 1);
        params.setMargins(dp(3), 0, dp(3), 0);
        row.addView(button, params);
        return button;
    }

    private void setStatus(String message, int color) {
        statusText.setText("●  " + message);
        statusText.setTextColor(color);
    }

    private void connectUsb() {
        stopDemo();
        if (usbManager == null) {
            setStatus("USB Host не поддерживается", RED);
            return;
        }
        List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        if (drivers.isEmpty()) {
            setStatus("Arduino не найдена. Проверь OTG и кабель", RED);
            return;
        }
        UsbSerialDriver driver = drivers.get(0);
        if (!usbManager.hasPermission(driver.getDevice())) {
            pendingDriver = driver;
            Intent permissionIntent = new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, permissionIntent, flags);
            usbManager.requestPermission(driver.getDevice(), pendingIntent);
            setStatus("Разреши приложению доступ к USB", MUTED);
        } else {
            openSerial(driver);
        }
    }

    private void openSerial(UsbSerialDriver driver) {
        disconnectInternal(false);
        UsbDeviceConnection connection = usbManager.openDevice(driver.getDevice());
        if (connection == null) {
            setStatus("Не удалось открыть USB. Закрой ArduinoDroid и терминал", RED);
            return;
        }
        try {
            UsbSerialPort port = driver.getPorts().get(0);
            port.open(connection);
            port.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            serialPort = port;
            currentDevice = driver.getDevice();
            reading = true;
            long id = ++sessionId;
            connectButton.setText("Отключить USB");
            setStatus("Подключено: " + currentDevice.getDeviceName() + " · 9600 бод", GREEN);
            radar.reset();
            startReader(port, id);
        } catch (Exception e) {
            try { connection.close(); } catch (Exception ignored) { }
            serialPort = null;
            currentDevice = null;
            setStatus("Ошибка подключения: " + e.getMessage(), RED);
        }
    }

    private void startReader(UsbSerialPort port, long id) {
        Thread thread = new Thread(() -> {
            byte[] buffer = new byte[256];
            StringBuilder received = new StringBuilder();
            try {
                while (reading && id == sessionId) {
                    int count = port.read(buffer, 1000);
                    if (count <= 0) continue;
                    String chunk = new String(buffer, 0, count, StandardCharsets.US_ASCII);
                    for (int i = 0; i < chunk.length(); i++) {
                        char c = chunk.charAt(i);
                        if (c == '\n') {
                            String line = received.toString().trim();
                            received.setLength(0);
                            if (!line.isEmpty()) {
                                handler.post(() -> {
                                    if (reading && id == sessionId) processLine(line);
                                });
                            }
                        } else if (c != '\r') {
                            if (received.length() < 200) received.append(c);
                            else received.setLength(0);
                        }
                    }
                }
            } catch (Exception e) {
                handler.post(() -> {
                    if (reading && id == sessionId) disconnect("USB-соединение прервано");
                });
            }
        }, "SonarUsbReader");
        thread.setDaemon(true);
        thread.start();
    }

    private void processLine(String line) {
        Matcher matcher = DATA_PATTERN.matcher(line);
        if (!matcher.find()) return;
        try {
            int angle = Integer.parseInt(matcher.group(1));
            float distance = Float.parseFloat(matcher.group(2));
            if (angle < 0 || angle > 180 || Float.isNaN(distance) || Float.isInfinite(distance)) return;
            acceptMeasurement(angle, distance, false);
        } catch (NumberFormatException ignored) { }
    }

    private void acceptMeasurement(int angle, float distance, boolean demo) {
        radar.updateMeasurement(angle, distance);
        angleText.setText(angle + "°");
        distanceText.setText(distance < 0 ? "Нет сигнала" : String.format(Locale.US, "%.1f см", distance));
        boolean detected = distance > 0 && distance <= 25;
        detectionText.setText(detected ? "ТРЕВОГА" : "НОРМА");
        detectionText.setTextColor(detected ? RED : GREEN);
        sampleText.setText((demo ? "DEMO · " : "USB · ") + String.format(Locale.US, "Angle: %d | Distance: %.2f", angle, distance));
    }

    private void startDemo() {
        disconnectInternal(false);
        demoRunning = true;
        demoAngle = 35;
        demoStep = 5;
        radar.reset();
        demoButton.setText("Стоп демо");
        setStatus("Демо: искусственные показания, без Arduino", MUTED);
        handler.post(demoTicker);
    }

    private void stopDemo() {
        demoRunning = false;
        handler.removeCallbacks(demoTicker);
        if (demoButton != null) demoButton.setText("Демо");
    }

    private void disconnectInternal(boolean showStatus) {
        reading = false;
        ++sessionId;
        UsbSerialPort oldPort = serialPort;
        serialPort = null;
        currentDevice = null;
        pendingDriver = null;
        if (oldPort != null) {
            try { oldPort.close(); } catch (IOException ignored) { }
        }
        if (connectButton != null) connectButton.setText("Подключить USB");
        if (showStatus) setStatus("USB отключено", MUTED);
    }

    private void disconnect(String message) {
        disconnectInternal(false);
        setStatus(message, MUTED);
    }

    @Override
    protected void onDestroy() {
        stopDemo();
        disconnectInternal(false);
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
