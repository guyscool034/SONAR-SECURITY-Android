package com.sonarsecurity.radar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class RadarView extends View {
    private static final int BACKGROUND = Color.rgb(5, 19, 22);
    private static final int GREEN = Color.rgb(51, 239, 145);
    private static final int RED = Color.rgb(255, 92, 81);
    private static final int MUTED = Color.rgb(66, 127, 113);
    private static final int MAX_RANGE_CM = 350;
    private static final long TARGET_LIFETIME_MS = 12000;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Target> targets = new ArrayList<>();
    private final RectF arcBox = new RectF();
    private float sweepAngle = 90f;
    private float lastDistance = -1f;
    private boolean hasScan = false;

    private static class Target {
        int angle;
        float distance;
        long seenAt;
        Target(int angle, float distance, long seenAt) {
            this.angle = angle;
            this.distance = distance;
            this.seenAt = seenAt;
        }
    }

    public RadarView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void updateMeasurement(int angle, float distance) {
        sweepAngle = Math.max(0, Math.min(180, angle));
        lastDistance = distance;
        hasScan = true;
        long now = android.os.SystemClock.uptimeMillis();
        if (distance > 1f && distance <= MAX_RANGE_CM) {
            int rounded = Math.round(angle / 5f) * 5;
            Target match = null;
            for (Target t : targets) {
                if (t.angle == rounded) {
                    match = t;
                    break;
                }
            }
            if (match == null) {
                targets.add(new Target(rounded, distance, now));
            } else {
                match.distance = distance;
                match.seenAt = now;
            }
        }
        invalidate();
    }

    public void clearTargets() {
        targets.clear();
        invalidate();
    }

    public void reset() {
        targets.clear();
        hasScan = false;
        sweepAngle = 90f;
        lastDistance = -1f;
        invalidate();
    }

    private void line(Canvas canvas, float x1, float y1, float x2, float y2, int color, float width, int alpha) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(width);
        paint.setColor(color);
        paint.setAlpha(alpha);
        canvas.drawLine(x1, y1, x2, y2, paint);
    }

    private void text(Canvas canvas, String value, float x, float y, float size, int color, Paint.Align align) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setAlpha(255);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        paint.setTextSize(size);
        paint.setTextAlign(align);
        canvas.drawText(value, x, y, paint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(BACKGROUND);
        float density = getResources().getDisplayMetrics().density;
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h - 35f * density;
        float r = Math.max(10f, Math.min((w - 35f * density) / 2f, cy - 30f * density));

        for (int i = 1; i <= 4; i++) {
            float ringRadius = r * i / 4f;
            arcBox.set(cx - ringRadius, cy - ringRadius, cx + ringRadius, cy + ringRadius);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1f * density);
            paint.setColor(MUTED);
            paint.setAlpha(i == 4 ? 220 : 115);
            canvas.drawArc(arcBox, 180, 180, false, paint);
            text(canvas, (MAX_RANGE_CM * i / 4) + " cm", cx + 6f * density,
                    cy - ringRadius + 12f * density, 9f * density, MUTED, Paint.Align.LEFT);
        }

        for (int a = 0; a <= 180; a += 30) {
            double radians = Math.toRadians(a);
            float x = cx + r * (float)Math.cos(radians);
            float y = cy - r * (float)Math.sin(radians);
            line(canvas, cx, cy, x, y, MUTED, 1f * density, 70);
        }

        line(canvas, cx - r, cy, cx + r, cy, GREEN, 1.6f * density, 190);
        text(canvas, "180°", cx - r, cy + 18f * density, 11f * density, MUTED, Paint.Align.LEFT);
        text(canvas, "0°", cx + r, cy + 18f * density, 11f * density, MUTED, Paint.Align.RIGHT);
        text(canvas, "90°", cx, cy - r - 9f * density, 11f * density, MUTED, Paint.Align.CENTER);

        long now = android.os.SystemClock.uptimeMillis();
        Iterator<Target> iterator = targets.iterator();
        while (iterator.hasNext()) {
            Target target = iterator.next();
            long age = now - target.seenAt;
            if (age > TARGET_LIFETIME_MS) {
                iterator.remove();
                continue;
            }
            float rr = r * Math.min(1f, target.distance / MAX_RANGE_CM);
            double angle = Math.toRadians(target.angle);
            float x = cx + rr * (float)Math.cos(angle);
            float y = cy - rr * (float)Math.sin(angle);
            int color = target.distance <= 25f ? RED : GREEN;
            int alpha = Math.max(35, 255 - (int)(age * 220 / TARGET_LIFETIME_MS));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            paint.setAlpha(alpha / 4);
            canvas.drawCircle(x, y, 8f * density, paint);
            paint.setAlpha(alpha);
            canvas.drawCircle(x, y, 3.2f * density, paint);
        }

        if (hasScan) {
            double radians = Math.toRadians(sweepAngle);
            float endX = cx + r * (float)Math.cos(radians);
            float endY = cy - r * (float)Math.sin(radians);
            line(canvas, cx, cy, endX, endY, GREEN, 2.6f * density, 255);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(GREEN);
        paint.setAlpha(255);
        canvas.drawCircle(cx, cy, 4f * density, paint);
        if (hasScan && lastDistance > 0 && lastDistance <= 25f) {
            text(canvas, "ОБНАРУЖЕН ОБЪЕКТ", cx, 19f * density, 12f * density, RED, Paint.Align.CENTER);
        }
        if (!targets.isEmpty()) postInvalidateDelayed(400);
    }
}
